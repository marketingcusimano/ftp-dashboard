# Dashboard FTP → CSV → Web

Visualizza in tempo reale i dati del file `generalb2b.csv` dal tuo server FTP.

## Avvio locale
```bash
npm install
cp .env.example .env
# (modifica .env con le tue credenziali)
npm start
```
Apri http://localhost:3000
